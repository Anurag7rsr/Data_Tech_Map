package com.psa.flightapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightReservationApp6Application {

	public static void main(String[] args) {
		SpringApplication.run(FlightReservationApp6Application.class, args);
	}

}
