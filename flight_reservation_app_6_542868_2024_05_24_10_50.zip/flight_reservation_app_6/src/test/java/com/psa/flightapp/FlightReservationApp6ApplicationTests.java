package com.psa.flightapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightReservationApp6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
