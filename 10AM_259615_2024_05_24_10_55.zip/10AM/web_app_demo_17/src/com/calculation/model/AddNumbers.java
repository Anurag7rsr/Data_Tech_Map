package com.calculation.model;

public class AddNumbers {
	
	public int addNumbers(int x, int y) {
		return x+y;
	}

}
