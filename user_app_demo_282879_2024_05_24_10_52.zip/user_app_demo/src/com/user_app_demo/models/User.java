package com.user_app_demo.models;

import java.sql.*;

public class User {
	private Statement stmnt;
	public void addRegistration(String firstName,String lastName,String emailId,String city, Connection con) {
		try {
			stmnt = con.createStatement();
			stmnt.executeUpdate("insert into registration values('"+firstName+"','"+lastName+"','"+emailId+"','"+city+"')");	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ResultSet showRegistration(Connection con) {
		try {
			Statement stmnt = con.createStatement();
			ResultSet results = stmnt.executeQuery("Select * from registration");
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void deleteReg(String emailId, Connection con) {
		try {
			Statement stmnt = con.createStatement();
			stmnt.executeUpdate("DELETE FROM registration WHERE emailid='"+emailId+"'");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
