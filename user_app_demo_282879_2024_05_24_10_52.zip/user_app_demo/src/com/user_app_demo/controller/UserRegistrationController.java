package com.user_app_demo.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.user_app_demo.models.DatabaseConnection;
import com.user_app_demo.models.User;

@WebServlet("/userRegistrationController")
public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public UserRegistrationController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/views/userRegistration.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String emailId = request.getParameter("emailid");
		String city = request.getParameter("city");
		DatabaseConnection db = new DatabaseConnection();
		Connection con = db.establishConnection();
		User user = new User();
		user.addRegistration(firstName,lastName,emailId,city,con);
		request.setAttribute("msg", "Data saved");
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/views/userRegistration.jsp");
		rd.include(request, response);
	}

}
